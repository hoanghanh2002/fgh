<?php
session_start();
if($_SESSION["userloged"]){
    unset($_SESSION['userloged']);
    header("location:login.php");
}

?>